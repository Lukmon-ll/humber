export default function Footer() {

  return(

    <footer id="footer">
      <div>&copy; Copyright Lukmon, 2023.</div>
    </footer>
  );
}