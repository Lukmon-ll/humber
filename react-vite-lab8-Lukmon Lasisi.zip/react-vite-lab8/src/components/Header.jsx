export default function Header() {

  return (
    <header className="header">
      <h2 id="site-name">
        <a href="/">Open Trivia Questions</a>
      </h2>
    </header>

  );
}